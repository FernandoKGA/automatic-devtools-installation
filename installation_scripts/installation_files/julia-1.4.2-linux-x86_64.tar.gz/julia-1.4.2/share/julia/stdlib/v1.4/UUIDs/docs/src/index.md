# UUIDs

```@docs
UUIDs.uuid1
UUIDs.uuid4
UUIDs.uuid5
UUIDs.uuid_version
```
