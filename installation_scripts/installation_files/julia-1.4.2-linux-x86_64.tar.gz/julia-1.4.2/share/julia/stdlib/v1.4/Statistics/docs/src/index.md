# Statistics

The Statistics module contains basic statistics functionality.

!!! note
    To use any of the examples described below, run `using Statistics` and then the code from the example.

```@docs
Statistics.std
Statistics.stdm
Statistics.var
Statistics.varm
Statistics.cor
Statistics.cov
Statistics.mean!
Statistics.mean
Statistics.median!
Statistics.median
Statistics.middle
Statistics.quantile!
Statistics.quantile
```
